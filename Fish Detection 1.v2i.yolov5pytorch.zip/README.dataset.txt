# Fish Detection 1 > 2025-07-20 10:16pm
https://universe.roboflow.com/fishdetection-oji58/fish-detection-1-9tpio

Provided by a Roboflow user
License: CC BY 4.0

